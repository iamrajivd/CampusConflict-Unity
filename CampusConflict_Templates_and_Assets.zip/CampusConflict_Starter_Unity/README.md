# Campus Conflict Unity Project

This is the starter Unity project for the game 'Campus Conflict'.